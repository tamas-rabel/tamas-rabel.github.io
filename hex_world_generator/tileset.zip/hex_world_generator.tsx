<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.0" name="hex_world_generator" tilewidth="104" tileheight="90" tilecount="13" columns="0">
 <grid orientation="orthogonal" width="1" height="1"/>
 <tile id="0">
  <image width="104" height="90" source="tiles/costal_water.png"/>
 </tile>
 <tile id="1">
  <image width="104" height="90" source="tiles/desert_sandy.png"/>
 </tile>
 <tile id="2">
  <image width="104" height="90" source="tiles/grass.png"/>
 </tile>
 <tile id="3">
  <image width="104" height="90" source="tiles/forested_hills.png"/>
 </tile>
 <tile id="4">
  <image width="104" height="90" source="tiles/heavy_forest.png"/>
 </tile>
 <tile id="5">
  <image width="104" height="90" source="tiles/hills.png"/>
 </tile>
 <tile id="6">
  <image width="104" height="90" source="tiles/hills_green.png"/>
 </tile>
 <tile id="7">
  <image width="104" height="90" source="tiles/jungle.png"/>
 </tile>
 <tile id="8">
  <image width="104" height="90" source="tiles/jungle_hills.png"/>
 </tile>
 <tile id="9">
  <image width="104" height="90" source="tiles/light_forest.png"/>
 </tile>
 <tile id="10">
  <image width="104" height="90" source="tiles/mountains.png"/>
 </tile>
 <tile id="11">
  <image width="104" height="90" source="tiles/swamp.png"/>
 </tile>
 <tile id="12">
  <image width="104" height="90" source="tiles/farmland.png"/>
 </tile>
</tileset>
